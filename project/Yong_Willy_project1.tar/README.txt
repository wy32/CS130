UP Key: 	Top view
DOWN Key: 	Front view
LEFT key:	Side view
SPACE:		Subdivide
